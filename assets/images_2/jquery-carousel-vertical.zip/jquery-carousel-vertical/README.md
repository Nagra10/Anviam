# carousel-vertical
 jQuery plugin for creating carousel sliders. Inspired to Owl Carousel 2, but it works vertically
